var currentEventId = ''
var currentUserId = ''